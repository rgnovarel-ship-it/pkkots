# NOVAREL Suite

Deux services complémentaires :

- `novarel/` — le moteur de simulation NOVAREL (app.py)
- `capital/` — NOVAREL CAPITAL, le Finance Brain (app_capital.py)

Voir `capital/README.md` pour le détail du fonctionnement de NOVAREL CAPITAL
et la façon dont les deux applications communiquent.

Déploiement : chaque dossier est déployé comme un service Render séparé,
partageant ce même dépôt (build/start command pointant vers le bon sous-dossier).
