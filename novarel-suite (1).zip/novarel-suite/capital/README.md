# NOVAREL CAPITAL — le Finance Brain de NOVAREL

## Pourquoi cette application

Dans NOVAREL, le module `MODULES` annonce un **"Finance Brain"** ("Suit CA, marge,
cash et risque") — mais aucune table ni aucune fonction ne l'implémente. Chaque
expérience (`experiments`) est évaluée **isolément** : NOVAREL sait dire "cette
stratégie a gagné 12 € cette fois", mais ne calcule jamais de courbe de capital,
de drawdown, ni d'exposition par catégorie.

**NOVAREL CAPITAL** est une application séparée et complémentaire qui comble ce
vide : elle transforme le flux d'expériences individuelles de NOVAREL en un
véritable portefeuille simulé, avec ses propres métriques de risque, et peut
renvoyer des recommandations à NOVAREL.

Aucune donnée ni action réelle : c'est une couche d'analyse au-dessus d'un
moteur déjà 100% simulé.

## Ce qu'elle fait

1. **Synchronisation** : toutes les `poll_seconds` (20s par défaut), elle
   interroge NOVAREL pour récupérer les nouvelles expériences. Elle essaie
   d'abord `GET /api/export/experiments` (historique complet, si disponible),
   sinon se replie sur `GET /api/state` (fenêtre limitée). Testé contre les
   deux versions de NOVAREL (avec et sans export) — fonctionne dans les
   deux cas.
2. **Capital cumulé** : chaque expérience ajoute son `actual_profit` (déjà net
   de frais) au capital simulé. Un capital de départ configurable (5000 € par
   défaut) sert de référence.
3. **Métriques de portefeuille** que NOVAREL ne calcule pas :
   - Drawdown courant et maximal (chute depuis le point le plus haut) ;
   - Rendement total ;
   - Rentabilité et nombre de trades par catégorie ;
   - Taux de réussite pondéré sur l'ensemble du portefeuille.
4. **Verdicts (Finance Brain)** : règles de gestion du risque lisibles :
   - Drawdown ≥ 25% → "Drawdown critique", recommande `risk_fraction=0.01` ;
   - Drawdown ≥ 12% → "Drawdown élevé", recommande `risk_fraction=0.10` ;
   - Portefeuille stable et croissant → suggère d'augmenter légèrement le risque ;
   - Catégorie déficitaire (≥5 trades, profit net négatif) → alerte dédiée.
   Un cooldown de 5 minutes évite de spammer le même verdict.
5. **Boucle de rétroaction optionnelle** (`auto_apply`, **désactivée par
   défaut**) : si activée, un verdict avec une `risk_fraction` suggérée est
   automatiquement envoyé à `POST {NOVAREL}/api/settings`. Testé de bout en
   bout avec deux vrais serveurs : un drawdown simulé de 40% a bien fait
   passer `risk_fraction` de `0.10` à `0.01` dans NOVAREL.
6. **Tableau de bord** (`/`) : courbe de capital, répartition par catégorie,
   flux de verdicts, réglages — auto-rafraîchi toutes les 15s.

## Ce qui a été testé réellement (pas juste relu)

- Deux vrais serveurs Flask (NOVAREL + CAPITAL) communiquant en HTTP réel sur
  `127.0.0.1`, pas de simulation en mémoire.
- Synchronisation avec export CSV complet : 22 expériences intégrées, capital
  et répartition par catégorie corrects.
- **Idempotence** : synchroniser plusieurs fois de suite ne duplique rien
  (contrainte `UNIQUE` sur `source_experiment_id`), capital inchangé au 2e et
  3e appel.
- **Repli automatique** vers `/api/state` testé contre une version de NOVAREL
  sans `/api/export` : fonctionne, 12 expériences récupérées.
- **Échec propre** d'un `auto_apply` contre une version sans `/api/settings` :
  pas de crash, message d'erreur clair journalisé dans le verdict.
- Tableau de bord HTML : chargement 200 OK.
- Endpoint de reset : refuse sans `?confirm=yes` (400), fonctionne avec.

## Déploiement

Application Flask indépendante, à déployer comme **second service** (par
exemple sur Render, à côté de NOVAREL) :

```bash
pip install -r requirements.txt
export NOVAREL_BASE_URL=https://<url-de-novarel>
export PORT=5100
python3 app_capital.py
```

Variables d'environnement :
- `NOVAREL_BASE_URL` : URL de base de NOVAREL (défaut `http://127.0.0.1:5000`,
  modifiable aussi depuis le tableau de bord).
- `PORT` : port d'écoute (défaut `5100`).
- `NOVAREL_CAPITAL_WORKER_ENABLED` : mettre à `0` pour désactiver la
  synchronisation automatique en tâche de fond (utile pour les tests).

## Routes principales

| Route | Méthode | Rôle |
|---|---|---|
| `/` | GET | Tableau de bord |
| `/health` | GET | État de santé |
| `/api/capital/state` | GET | Métriques + verdicts + historique de synchro |
| `/api/capital/sync` | POST | Déclenche une synchronisation immédiate |
| `/api/capital/verdicts` | GET | Historique des verdicts |
| `/api/capital/settings` | GET/POST | Lire/modifier la configuration |
| `/api/capital/reset` | POST `?confirm=yes` | Réinitialise le portefeuille simulé |

## Garde-fous

- `auto_apply` est **désactivé par défaut**, comme tous les garde-fous de
  NOVAREL (`simulation_only`, `max_auto_purchase=0`).
- Même activée, la rétroaction ne fait que proposer une valeur de
  `risk_fraction` à NOVAREL — c'est NOVAREL lui-même qui la borne
  (`clamp(0.01, 0.50)` côté `/api/settings`).
- Aucune des deux applications n'effectue d'achat ni de transaction réelle.
